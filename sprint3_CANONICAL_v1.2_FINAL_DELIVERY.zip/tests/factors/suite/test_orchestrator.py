import pandas as pd
from src.econ.factors.orchestrator import FeaturePipeline

def test_orchestrator_streaks():
    df = pd.DataFrame({
        "vix": [10, 11, 12],
        "corr": [0.5, 0.6, 0.7]
    }, index=pd.date_range("2024-01-01", periods=3))
    pipe = FeaturePipeline()
    out = pipe.run(df)
    assert list(out["streak"]) == [1, 2, 3]