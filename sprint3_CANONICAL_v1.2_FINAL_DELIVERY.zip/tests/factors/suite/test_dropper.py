import pandas as pd
from src.econ.factors.dropper import MissingDataDropper

def test_dropper_behavior():
    df = pd.DataFrame({
        "vix": [10, None, 12],
        "corr": [0.5, 0.6, None]
    }, index=pd.date_range("2024-01-01", periods=3))
    dropper = MissingDataDropper()
    clean = dropper.drop_missing(df)
    assert len(clean) == 1