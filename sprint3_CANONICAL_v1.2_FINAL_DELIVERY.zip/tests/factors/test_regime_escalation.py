from econ.factors.streak_counter import effective_dropout_threshold

def test_escalation_applies():
    assert effective_dropout_threshold("high_vol", 0.81) == 3

def test_escalation_not_applies_low_prob():
    assert effective_dropout_threshold("high_vol", 0.80) == 5

def test_normal_regime():
    assert effective_dropout_threshold("normal", 0.99) == 5
