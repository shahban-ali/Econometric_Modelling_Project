import datetime
from src.econ.factors.streak_counter import TradingDayStreakCounter

def test_streak_counter_basic():
    counter = TradingDayStreakCounter()
    days = [
        datetime.date(2024, 1, 1),
        datetime.date(2024, 1, 2),
        datetime.date(2024, 1, 3),
        datetime.date(2024, 1, 5)
    ]
    streaks = [counter.update(day) for day in days]
    assert streaks == [1, 2, 3, 1]