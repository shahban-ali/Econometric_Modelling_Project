import numpy as np
from pathlib import Path

from econ.bl.posterior import PosteriorEngine


class TestPosteriorInMemoryViews:
    def test_compute_accepts_list_views(self, tmp_path):
        engine = PosteriorEngine()
        prior_returns = np.array([0.05, 0.07, 0.04, 0.06, 0.08])
        prior_cov = np.eye(5) * 0.04

        views = [
            {"asset": "AAPL", "view_return": 0.08, "confidence": 0.7},
            {"asset": "MSFT", "view_return": -0.02, "confidence": 0.5},
        ]

        result = engine.compute(
            prior_returns=prior_returns,
            prior_cov=prior_cov,
            views=views,
            tau=0.05,
            evidence_dir=tmp_path,
        )

        assert result.valid is True
        assert result.posterior_returns.shape == prior_returns.shape
        assert result.posterior_cov.shape == prior_cov.shape

    def test_evidence_written_to_evidence_dir(self, tmp_path):
        engine = PosteriorEngine()
        prior_returns = np.array([0.05, 0.07, 0.04, 0.06, 0.08])
        prior_cov = np.eye(5) * 0.04

        views = [{"asset": "AAPL", "view_return": 0.08, "confidence": 0.7}]

        engine.compute(
            prior_returns=prior_returns,
            prior_cov=prior_cov,
            views=views,
            tau=0.05,
            evidence_dir=tmp_path,
        )

        # Must exist under evidence_dir
        assert (tmp_path / "manifest.json").exists()
        assert (tmp_path / "bl/posterior_examples.json").exists()
        assert (tmp_path / "views/validation_report.json").exists()

    def test_no_leakage_to_default_path(self, tmp_path):
        engine = PosteriorEngine()
        prior_returns = np.array([0.05, 0.07, 0.04, 0.06, 0.08])
        prior_cov = np.eye(5) * 0.04

        views = [{"asset": "AAPL", "view_return": 0.08, "confidence": 0.7}]

        default_path = Path("evidence/sprint3")
        before = set(default_path.rglob("*")) if default_path.exists() else set()

        engine.compute(
            prior_returns=prior_returns,
            prior_cov=prior_cov,
            views=views,
            tau=0.05,
            evidence_dir=tmp_path,
        )

        after = set(default_path.rglob("*")) if default_path.exists() else set()
        new_files = after - before

        # No new files in default path caused by this call
        assert len(new_files) == 0, f"Leakage to default evidence path detected: {sorted([str(p) for p in new_files])}"
