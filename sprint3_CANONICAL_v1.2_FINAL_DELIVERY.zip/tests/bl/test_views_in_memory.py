import numpy as np
import pytest
from pathlib import Path

from econ.bl.views import ViewsEngine


class TestViewsEngineInMemory:
    @pytest.fixture
    def engine(self):
        return ViewsEngine()

    @pytest.fixture
    def valid_views(self):
        return [
            {"asset": "AAPL", "view_return": 0.08, "confidence": 0.7},
            {"asset": "MSFT", "view_return": -0.02, "confidence": 0.5},
        ]

    @pytest.fixture
    def prior_cov(self):
        return np.eye(5) * 0.04

    def test_build_from_list_valid_input(self, engine, valid_views, prior_cov):
        result = engine.build_from_list(valid_views, prior_cov)
        k = len(valid_views)
        n = prior_cov.shape[0]

        assert result.valid is True
        assert result.P.shape == (k, n)
        assert result.Q.shape == (k,)
        assert result.Omega.shape == (k, k)
        assert result.errors == []

    def test_build_from_list_determinism(self, engine, valid_views, prior_cov):
        r1 = engine.build_from_list(valid_views, prior_cov)
        r2 = engine.build_from_list(valid_views, prior_cov)

        np.testing.assert_array_equal(r1.P, r2.P)
        np.testing.assert_array_equal(r1.Q, r2.Q)
        np.testing.assert_array_equal(r1.Omega, r2.Omega)

    @pytest.mark.parametrize("bad_confidence", [0.0, 1.0, -0.2, 1.5, -1.0])
    def test_strict_reject_invalid_confidence(self, engine, prior_cov, bad_confidence):
        invalid_views = [{"asset": "AAPL", "view_return": 0.08, "confidence": bad_confidence}]
        result = engine.build_from_list(invalid_views, prior_cov)

        assert result.valid is False
        assert result.P.size == 0
        assert result.Q.size == 0
        assert result.Omega.size == 0
        assert len(result.errors) > 0
        assert any("confidence" in e.lower() for e in result.errors)

    def test_no_clamping_code_exists(self):
        source = Path("src/econ/bl/views.py").read_text()

        forbidden = [
            "max(min(",
            "np.clip(",
            ".clip(",
            "clamp(",
        ]
        for pat in forbidden:
            assert pat not in source, f"Forbidden clamping pattern found: {pat}"
