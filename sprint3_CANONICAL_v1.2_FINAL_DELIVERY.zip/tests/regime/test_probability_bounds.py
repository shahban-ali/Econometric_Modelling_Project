from econ.regime.classifier import RegimeClassifier

def test_probability_bounds_extremes():
    clf = RegimeClassifier(k=1.0)
    r1 = clf.classify_from_z(5.0)
    r2 = clf.classify_from_z(-5.0)
    assert 0.0 <= r1.probability <= 1.0
    assert 0.0 <= r2.probability <= 1.0
