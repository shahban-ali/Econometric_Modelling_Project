from econ.regime.publisher import build_regime_event

def test_idempotency_key_deterministic():
    asof = "2024-01-15T14:30:00Z"
    e1 = build_regime_event("high_vol", 0.82, asof)
    e2 = build_regime_event("high_vol", 0.82, asof)
    assert e1["idempotency_key"] == "regime:2024-01-15T14:30:00Z"
    assert e1["idempotency_key"] == e2["idempotency_key"]
