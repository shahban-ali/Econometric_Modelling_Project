import datetime


class ConsecutiveDayStreakCounter:
    def __init__(self):
        self.streak = 0
        self.last_day = None

    def update(self, day: datetime.date) -> int:
        if self.last_day is None:
            self.streak = 1
        else:
            if (day - self.last_day).days == 1:
                self.streak += 1
            else:
                self.streak = 1

        self.last_day = day
        return self.streak


# Canonical alias
TradingDayStreakCounter = ConsecutiveDayStreakCounter


def effective_dropout_threshold(regime: str, probability: float) -> int:
    if regime == "high_vol" and probability > 0.8:
        return 3
    return 5
