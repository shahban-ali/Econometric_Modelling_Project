import pandas as pd
from pathlib import Path

class MissingDataDropper:
    def __init__(self):
        self.dropped_dates = []

    def drop_missing(self, df: pd.DataFrame):
        cleaned = df.dropna()
        self.dropped_dates = df[df.isnull().any(axis=1)].index.tolist()
        return cleaned

    def write_evidence(self, path='evidence/sprint2/factors/drop_events.json'):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        import json
        with open(path, "w") as f:
            json.dump([str(d) for d in self.dropped_dates], f, indent=2)