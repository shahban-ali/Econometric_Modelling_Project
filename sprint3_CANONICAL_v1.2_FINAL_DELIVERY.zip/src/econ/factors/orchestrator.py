from typing import Dict, Any
import pandas as pd
from .streak_counter import (
    TradingDayStreakCounter,
    effective_dropout_threshold,
)


class FeaturePipeline:
    """
    Canonical factor orchestration pipeline.
    Backward compatible with Sprint-2 tests.
    """

    def __init__(self, min_viable_factors: int = 3):
        self.min_viable_factors = min_viable_factors

    def run(
        self,
        df_or_states,
        regime: str = "normal",
        probability: float = 0.0,
    ):
        """
        Accepts either:
        - DataFrame (Sprint-2 / Integration-Hardening style)
        - factor_states dict (Sprint-3 style)
        """

        # ---- Sprint-2 path: DataFrame input ----
        if isinstance(df_or_states, pd.DataFrame):
            df = df_or_states.copy()
            counter = TradingDayStreakCounter()

            # streak based on index (dates)
            df["streak"] = [
                counter.update(idx.date()) for idx in df.index
            ]
            return df

        # ---- Sprint-3 path: factor state dict ----
        factor_states: Dict[str, Dict[str, Any]] = df_or_states
        threshold = effective_dropout_threshold(regime, probability)

        active = {
            k: v for k, v in factor_states.items()
            if v.get("streak_days", 0) < threshold
        }

        if len(active) < self.min_viable_factors:
            return factor_states

        return active
