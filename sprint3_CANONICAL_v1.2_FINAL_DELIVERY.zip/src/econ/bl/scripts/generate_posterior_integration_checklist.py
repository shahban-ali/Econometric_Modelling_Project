from __future__ import annotations

import json
import subprocess
from pathlib import Path
from datetime import datetime, timezone

REQUIRED_22 = [
    "manifest.json",
    "tau/calibration_samples.json",
    "tau/bounds_validation.json",
    "views/validation_report.json",
    "bl/posterior_examples.json",
    "bl/numerical_stability.json",
    "bl/determinism_check.json",
    "bl/latency_samples.json",
    "global/pipeline_integration_test.json",
    "global/stress_test_2008_q4.json",
    "global/stress_test_2020_q1.json",
    "global/stress_test_normal.json",
    "resilience/circuit_breaker.json",
    "resilience/degradation_test.json",
    "resilience/recovery_timing.json",
    "contracts/regime_api_pact.json",
    "contracts/priors_api_pact.json",
    "contracts/factor_health_pact.json",
    "monitoring/dashboard_export.json",
    "diagnostics/performance_attribution.json",
    "integration/regime_propagation.json",
    "ci/test_report.txt",
    "ci/coverage.txt",
]

def iso_utc():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")

def get_git_sha() -> str:
    # best-effort; CANONICAL v1.2 allows UNKNOWN
    try:
        out = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True, check=True)
        return out.stdout.strip()
    except Exception:
        p = Path("COMMIT_SHA.txt")
        if p.exists():
            return p.read_text().strip()
        return "UNKNOWN"

def method_exists(file_path: str, needle: str) -> bool:
    p = Path(file_path)
    if not p.exists():
        return False
    return needle in p.read_text()

def evidence_22_present(evidence_dir: Path) -> tuple[bool, list[str]]:
    missing = []
    for rel in REQUIRED_22:
        if not (evidence_dir / rel).exists():
            missing.append(str(evidence_dir / rel))
    return (len(missing) == 0), missing

def main():
    checks = {}

    checks["views_engine_build_from_list"] = {
        "status": "PASS" if method_exists("src/econ/bl/views.py", "def build_from_list") else "FAIL",
        "evidence": ["src/econ/bl/views.py", "tests/bl/test_views_in_memory.py"],
        "notes": "ViewsEngine.build_from_list accepts List[Dict] and enforces strict bounds.",
    }

    checks["posterior_compute_evidence_dir"] = {
        "status": "PASS" if method_exists("src/econ/bl/posterior.py", "evidence_dir") else "FAIL",
        "evidence": ["src/econ/bl/posterior.py", "tests/bl/test_posterior_in_memory_views.py"],
        "notes": "PosteriorEngine.compute accepts evidence_dir and writes evidence there.",
    }

    checks["init_accepts_config_dict"] = {
        "status": "PASS" if (method_exists("src/econ/bl/views.py", "config: Optional[Dict") and method_exists("src/econ/bl/posterior.py", "config: Optional[Dict")) else "FAIL",
        "evidence": ["src/econ/bl/views.py", "src/econ/bl/posterior.py"],
        "notes": "__init__ accepts config dict injection for both engines.",
    }

    # Canonical PosteriorResult location
    types_ok = Path("src/econ/bl/types.py").exists()
    checks["posterior_result_schema_stable"] = {
        "status": "PASS" if (types_ok and method_exists("src/econ/bl/types.py", "class PosteriorResult")) else "FAIL",
        "evidence": ["src/econ/bl/types.py"],
        "notes": "PosteriorResult defined canonically in src/econ/bl/types.py with stable field names.",
    }

    # Confidence strict reject bounds
    bounds_ok = method_exists("src/econ/bl/views.py", "self.confidence_bounds = (0.01, 0.99)")
    checks["confidence_bounds_strict_reject_0_01_to_0_99"] = {
        "status": "PASS" if bounds_ok else "FAIL",
        "evidence": ["src/econ/bl/views.py", "tests/bl/test_views_in_memory.py"],
        "notes": "Bounds [0.01,0.99] are enforced; invalid views rejected.",
    }

    # Evidence 22 artifacts under override dir
    override_dir = Path("evidence/sprint3/override_run")
    ok22, missing = evidence_22_present(override_dir)
    checks["evidence_22_artifacts_written_under_override_dir"] = {
        "status": "PASS" if ok22 else "FAIL",
        "evidence": [str(override_dir)],
        "notes": "Missing: " + (", ".join(missing) if missing else "None"),
    }

    overall = "PASS" if all(v["status"] == "PASS" for v in checks.values()) else "FAIL"

    out = {
        "component": "PosteriorEngine",
        "spec_version": "CANONICAL-v1.2",
        "generated_at_utc": iso_utc(),
        "commit_sha": get_git_sha(),
        "checks": checks,
        "overall_status": overall,
    }

    out_path = Path("evidence/operator_ready/posterior_integration_checklist.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2) + "\n")
    print(out["overall_status"], "-", out_path)

if __name__ == "__main__":
    main()
