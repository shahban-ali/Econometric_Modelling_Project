import json
from pathlib import Path
from datetime import datetime, timezone

OUT = Path("evidence/sprint3/CANONICAL/contracts")
OUT.mkdir(parents=True, exist_ok=True)

contract = {
    "consumer": {"name": "BLPosterior"},
    "provider": {"name": "PriorsAPI"},
    "interaction": {
        "request": {
            "method": "GET",
            "path": "/priors/v1/current",
            "query": {"universe_id": "TOP50"}
        },
        "response": {
            "status": 200,
            "body": {
                "universe_id": "TOP50",
                "as_of": "2024-01-15T00:00:00Z",
                "schema_version": "sprint2-v2.1.0",
                "prior_mu": ["float"],
                "prior_cov": [["float"]]
            }
        }
    },
    "schema_version_expected": "sprint2-v2.1.0",
    "generated_at": datetime.now(timezone.utc).isoformat()
}

(OUT / "priors_api_pact.json").write_text(json.dumps(contract, indent=2))
print("OK: priors_api_pact.json regenerated")
