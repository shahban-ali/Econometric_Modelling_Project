from __future__ import annotations

import json
import time
import numpy as np
from pathlib import Path

from econ.bl.posterior import PosteriorEngine

SEED = 20250202

def _iso_utc() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def _write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True))

def main() -> int:
    np.random.seed(SEED)
    root = Path("evidence/sprint3/resilience")
    root.mkdir(parents=True, exist_ok=True)

    engine = PosteriorEngine(config=None)

    prior_returns = np.array([0.05, 0.07, 0.04, 0.06, 0.08], dtype=float)

    # Create a deterministically ill-conditioned covariance
    cov = np.eye(5, dtype=float) * 0.04
    cov[0,0] = 1e-14

    views = [{"asset": "AAPL", "view_return": 0.08, "confidence": 0.7}]

    result = engine.compute(
        prior_returns=prior_returns,
        prior_cov=cov,
        views=views,
        tau=0.05,
        evidence_dir=Path("evidence/sprint3"),
    )

    evidence = {
        "generated_at_utc": _iso_utc(),
        "seed": SEED,
        "scenario": "ill_conditioned_covariance",
        "condition_number": float(np.linalg.cond(cov)),
        "posterior_valid": bool(result.valid),
        "errors": list(result.errors),
        "decisions": list(result.decisions),
    }
    _write_json(root / "circuit_breaker.json", evidence)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
