import json
from pathlib import Path

PACT = Path("evidence/sprint3/CANONICAL/contracts/priors_api_pact.json")
contract = json.loads(PACT.read_text())

assert "interaction" in contract, "Invalid pact: missing interaction"
assert "response" in contract["interaction"]
assert "body" in contract["interaction"]["response"]

provider_response = {
    "universe_id": "TOP50",
    "as_of": "2024-01-15T00:00:00Z",
    "schema_version": "sprint2-v2.1.0",
    "prior_mu": [0.01, 0.02],
    "prior_cov": [[0.04, 0.01], [0.01, 0.05]]
}

expected = contract["interaction"]["response"]["body"]

for field in expected:
    assert field in provider_response, f"Missing field: {field}"

assert provider_response["schema_version"] == contract["schema_version_expected"]

OUT = Path("evidence/sprint3/CANONICAL/contracts")
(OUT / "priors_provider_verification.json").write_text(
    json.dumps({"verified": True, "fields": list(expected.keys())}, indent=2)
)

print("OK: provider contract verified")
