import json
from pathlib import Path
from datetime import datetime, timezone

OUT = Path("evidence/sprint3/CANONICAL/monitoring")
OUT.mkdir(parents=True, exist_ok=True)

dashboard = {
    "title": "Sprint 3 — Black-Litterman Observability",
    "uid": "sprint3-bl-observability",
    "schemaVersion": 38,
    "version": 1,
    "timezone": "utc",
    "refresh": "10s",
    "time": {"from": "now-1h", "to": "now"},
    "panels": [
        {
            "type": "timeseries",
            "title": "Posterior Mean Return",
            "id": 1,
            "datasource": {"type": "prometheus", "uid": "PROMETHEUS"},
            "targets": [
                {
                    "expr": "bl_posterior_mean_return",
                    "legendFormat": "posterior_mean",
                }
            ],
            "gridPos": {"x": 0, "y": 0, "w": 12, "h": 8},
        },
        {
            "type": "timeseries",
            "title": "Posterior Volatility",
            "id": 2,
            "datasource": {"type": "prometheus", "uid": "PROMETHEUS"},
            "targets": [
                {
                    "expr": "bl_posterior_volatility",
                    "legendFormat": "posterior_vol",
                }
            ],
            "gridPos": {"x": 12, "y": 0, "w": 12, "h": 8},
        },
        {
            "type": "stat",
            "title": "Active Circuit Breaker",
            "id": 3,
            "datasource": {"type": "prometheus", "uid": "PROMETHEUS"},
            "targets": [
                {
                    "expr": "bl_circuit_breaker_active",
                    "legendFormat": "breaker",
                }
            ],
            "gridPos": {"x": 0, "y": 8, "w": 6, "h": 6},
        },
    ],
    "annotations": {"list": []},
    "templating": {"list": []},
    "editable": False,
    "tags": ["sprint3", "black-litterman", "observability"],
    "generated_at": datetime.now(timezone.utc).isoformat(),
}

(OUT / "dashboard_export.json").write_text(
    json.dumps(dashboard, indent=2)
)

print("OK: dashboard_export.json written")
