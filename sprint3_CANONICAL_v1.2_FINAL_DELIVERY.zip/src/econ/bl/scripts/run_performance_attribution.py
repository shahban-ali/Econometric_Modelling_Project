import numpy as np
import json
from pathlib import Path

OUT = Path("evidence/sprint3/CANONICAL/performance")
OUT.mkdir(parents=True, exist_ok=True)

# Simulated posterior & prior (canonical small example)
prior = np.array([0.05, 0.07, 0.04, 0.06, 0.08])
posterior = np.array([0.06, 0.065, 0.045, 0.055, 0.075])

delta = posterior - prior

result = {
    "prior_returns": prior.tolist(),
    "posterior_returns": posterior.tolist(),
    "attribution": {
        "total_shift": float(delta.sum()),
        "per_asset": delta.tolist()
    }
}

(Path(OUT / "performance_attribution.json")
 .write_text(json.dumps(result, indent=2)))

print("OK: performance_attribution.json written")
