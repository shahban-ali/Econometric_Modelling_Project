from __future__ import annotations

import json
import os
import hashlib
import time
from pathlib import Path
from typing import Dict, List

SEED = 20250202

REQUIRED_EVIDENCE = [
    "manifest.json",
    "tau/calibration_samples.json",
    "tau/bounds_validation.json",
    "views/validation_report.json",
    "bl/posterior_examples.json",
    "bl/numerical_stability.json",
    "bl/determinism_check.json",
    "bl/latency_samples.json",
    "global/pipeline_integration_test.json",
    "global/stress_test_2008_q4.json",
    "global/stress_test_2020_q1.json",
    "global/stress_test_normal.json",
    "resilience/circuit_breaker.json",
    "resilience/degradation_test.json",
    "resilience/recovery_timing.json",
    "contracts/regime_api_pact.json",
    "contracts/priors_api_pact.json",
    "contracts/factor_health_pact.json",
    "monitoring/dashboard_export.json",
    "diagnostics/performance_attribution.json",
    "integration/regime_propagation.json",
    "ci/test_report.txt",
    "ci/coverage.txt",
]

def _iso_utc() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def _sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def _bundle_hash(root: Path, rel_paths: List[str]) -> str:
    h = hashlib.sha256()
    for rp in sorted(rel_paths):
        p = root / rp
        h.update(rp.encode("utf-8"))
        h.update(b"\0")
        h.update(_sha256_file(p).encode("ascii"))
        h.update(b"\0")
    return h.hexdigest()

def main() -> int:
    root = Path("evidence/sprint3")
    commit_sha = os.getenv("GIT_SHA") or os.getenv("COMMIT_SHA") or "UNKNOWN"

    missing = [rp for rp in REQUIRED_EVIDENCE if not (root / rp).exists()]
    if missing:
        raise SystemExit(f"Missing evidence files: {missing}")

    hashes: Dict[str, str] = {rp: _sha256_file(root / rp) for rp in REQUIRED_EVIDENCE if rp != "manifest.json"}
    bundle_hash = _bundle_hash(root, [rp for rp in REQUIRED_EVIDENCE if rp != "manifest.json"])

    manifest = {
        "spec_version": "CANONICAL-v1.2",
        "generated_at_utc": _iso_utc(),
        "seed": SEED,
        "commit_sha": commit_sha,
        "artifact_count_expected": 22,
        "artifact_count_observed": len(REQUIRED_EVIDENCE),
        "bundle_hash_sha256": bundle_hash,
        "files": hashes,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
