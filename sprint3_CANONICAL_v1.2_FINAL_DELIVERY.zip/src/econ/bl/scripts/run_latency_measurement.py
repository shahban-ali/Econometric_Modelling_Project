from __future__ import annotations
import subprocess
import os
from pathlib import Path

def main() -> int:
    # Delegate to canonical runner (it writes bl/latency_samples.json)
    env = dict(os.environ)
    env["PYTHONPATH"] = env.get("PYTHONPATH", "src")
    p = subprocess.run(["python", "src/econ/bl/scripts/run_posterior_canonical.py"], env=env, capture_output=True, text=True)
    (Path("evidence/sprint3/ci").mkdir(parents=True, exist_ok=True))
    Path("evidence/sprint3/ci/latency_runner.log").write_text(p.stdout + "\n" + p.stderr)
    return p.returncode

if __name__ == "__main__":
    raise SystemExit(main())
