from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Dict, Any
import numpy as np


@dataclass
class ViewsResult:
    """Result from ViewsEngine.build_from_*() methods."""
    P: np.ndarray              # (k x n)
    Q: np.ndarray              # (k,)
    Omega: np.ndarray          # (k x k)
    valid: bool
    errors: List[str]


@dataclass
class PosteriorResult:
    """
    Result from PosteriorEngine.compute().

    INTEGRATION CONTRACT (v1.2):
    Sprint 4 expects exactly:
      posterior_returns, posterior_cov, valid, errors, decisions
    """
    posterior_returns: np.ndarray
    posterior_cov: np.ndarray
    valid: bool
    errors: List[str]
    decisions: List[str]

    condition_number: Optional[float] = None
    tau_used: Optional[float] = None
    views_applied: Optional[int] = None
    timestamp: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "posterior_returns": self.posterior_returns.tolist() if self.valid else [],
            "posterior_cov": self.posterior_cov.tolist() if self.valid else [],
            "valid": self.valid,
            "errors": self.errors,
            "decisions": self.decisions,
            "condition_number": self.condition_number,
            "tau_used": self.tau_used,
            "views_applied": self.views_applied,
            "timestamp": self.timestamp,
        }
