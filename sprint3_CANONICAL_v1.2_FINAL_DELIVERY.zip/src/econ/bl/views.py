from __future__ import annotations

from typing import Any, Dict, List, Optional
from pathlib import Path
import yaml
import numpy as np

from econ.bl.types import ViewsResult


class ViewsEngine:
    """
    Views construction for Black-Litterman model.

    CANONICAL v1.2 requirements:
      - supports YAML (build_from_yaml)
      - supports in-memory views (build_from_list)
      - STRICT REJECT (no clamping; invalid view => empty matrices + errors)
      - confidence bounds are [0.01, 0.99] (do not loosen)
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None, config_path: str = "config/bl.yaml"):
        self.config = config if config is not None else self._load_config(config_path)

        # fixed bounds required by Sprint 4 integration contract
        self.confidence_bounds = (0.01, 0.99)

        # optional mapping: asset -> index (Scenario Engine may supply)
        self.asset_index = self.config.get("asset_index", {})

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        p = Path(config_path)
        if p.exists():
            with p.open("r") as f:
                return yaml.safe_load(f) or {}
        return {}

    def build_from_yaml(self, views_path: str, prior_cov: np.ndarray) -> ViewsResult:
        with open(views_path, "r") as f:
            data = yaml.safe_load(f) or {}
        views = data.get("views", [])
        return self._build_views(views, prior_cov)

    def build_from_list(self, views: List[Dict[str, Any]], prior_cov: np.ndarray) -> ViewsResult:
        return self._build_views(views, prior_cov)

    def _build_views(self, views: List[Dict[str, Any]], prior_cov: np.ndarray) -> ViewsResult:
        errors: List[str] = []
        n = int(prior_cov.shape[0])

        # Validate first (STRICT REJECT)
        for i, v in enumerate(views):
            conf = v.get("confidence", None)
            if conf is None:
                errors.append(f"View {i}: missing confidence")
                continue
            if not (self.confidence_bounds[0] <= float(conf) <= self.confidence_bounds[1]):
                errors.append(
                    f"View {i}: confidence {conf} outside [{self.confidence_bounds[0]}, {self.confidence_bounds[1]}]"
                )

            if "asset" not in v:
                errors.append(f"View {i}: missing asset")
            if "view_return" not in v:
                errors.append(f"View {i}: missing view_return")

        if errors:
            return ViewsResult(
                P=np.array([]),
                Q=np.array([]),
                Omega=np.array([]),
                valid=False,
                errors=errors,
            )

        k = len(views)
        if k == 0:
            # no views is valid; returns empty view matrices but valid=True
            return ViewsResult(
                P=np.zeros((0, n)),
                Q=np.zeros((0,)),
                Omega=np.zeros((0, 0)),
                valid=True,
                errors=[],
            )

        P = np.zeros((k, n))
        Q = np.zeros((k,))
        Omega = np.zeros((k, k))

        # If asset_index isn't provided, we assume view asset strings map to 0..n-1 by order of appearance
        # Scenario Engine integration can pass asset_index via config.
        dynamic_index: Dict[str, int] = {}
        next_idx = 0

        def _idx(asset: str) -> int:
            nonlocal next_idx
            if asset in self.asset_index:
                return int(self.asset_index[asset])
            if asset not in dynamic_index:
                dynamic_index[asset] = next_idx
                next_idx += 1
            return dynamic_index[asset]

        # Construct P, Q, Omega deterministically
        for i, v in enumerate(views):
            asset = str(v["asset"])
            j = _idx(asset)
            if not (0 <= j < n):
                return ViewsResult(
                    P=np.array([]),
                    Q=np.array([]),
                    Omega=np.array([]),
                    valid=False,
                    errors=[f"View {i}: asset index out of range for asset={asset}, idx={j}, n={n}"],
                )

            P[i, j] = 1.0
            Q[i] = float(v["view_return"])

            conf = float(v["confidence"])
            # Uncertainty inversely related to confidence (no clamping)
            # Omega diagonal scaled by prior variance at that asset
            var_j = float(prior_cov[j, j]) if prior_cov.size else 1.0
            Omega[i, i] = (1.0 - conf) * var_j + 1e-12  # tiny epsilon for invertibility

        return ViewsResult(P=P, Q=Q, Omega=Omega, valid=True, errors=[])
