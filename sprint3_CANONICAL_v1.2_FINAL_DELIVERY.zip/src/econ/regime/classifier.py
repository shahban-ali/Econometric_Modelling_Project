import math
from dataclasses import dataclass

@dataclass(frozen=True)
class RegimeResult:
    regime: str
    probability: float  # always in [0,1]

def sigmoid(x: float) -> float:
    # numerically stable sigmoid
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    else:
        z = math.exp(x)
        return z / (1.0 + z)

def clamp01(p: float) -> float:
    return max(0.0, min(1.0, p))

class RegimeClassifier:
    """
    Mapping method:
      probability = sigmoid(k * z), clamped to [0,1]
    where z is a regime stress z-score proxy and k controls steepness.
    """
    def __init__(self, k: float = 1.0, enter: float = 0.60, exit: float = 0.40):
        self.k = float(k)
        self.enter = float(enter)
        self.exit = float(exit)
        self._state = "normal"

    def classify_from_z(self, z: float) -> RegimeResult:
        p = clamp01(sigmoid(self.k * float(z)))

        # simple hysteresis on regime label
        if self._state == "normal" and p >= self.enter:
            self._state = "high_vol"
        elif self._state == "high_vol" and p <= self.exit:
            self._state = "normal"

        return RegimeResult(regime=self._state, probability=p)

    def classify_now(self) -> dict:
        # In this sprint hardening: deterministic stub value (can be wired to real features later)
        # Choose a conservative value that doesn't violate contracts:
        z = 0.0
        r = self.classify_from_z(z)
        return {"regime": r.regime, "probability": r.probability}
