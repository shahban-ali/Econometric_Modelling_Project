from datetime import datetime, timezone
from fastapi import FastAPI
from typing import Dict

from econ.regime.classifier import RegimeClassifier

app = FastAPI(title="Regime API")
clf = RegimeClassifier()

def _iso_utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

@app.get("/regimes/v1/current")
def get_current_regime() -> Dict:
    """
    CONTRACT (canonical):
    {
      "regime": "high_vol",
      "probability": 0.82,
      "asof": "2024-01-15T14:30:00Z"
    }
    """
    asof = _iso_utc_now()

    # Minimal sample (replace with your real feature retrieval if you have it)
    # Keep deterministic + bounded semantics in classifier.
    result = clf.classify(features={"vix_z": 0.5, "corr_z": 0.3})

    return {
        "regime": result["regime"],
        "probability": float(result["probability"]),
        "asof": asof,
    }

# Optional deprecated alias (allowed but MUST NOT be used anywhere else)
@app.get("/regime")
def get_regime_deprecated_alias() -> Dict:
    return get_current_regime()
