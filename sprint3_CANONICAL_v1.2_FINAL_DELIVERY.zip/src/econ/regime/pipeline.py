from datetime import datetime
from regime_classifier_v3 import RegimeClassifier
import pandas as pd

clf = RegimeClassifier("regime_thresholds_v3.json")

def run_pipeline(row: dict):
    now = datetime.utcnow()
    df = pd.DataFrame([row], index=[now])
    pred = clf.classify_series(df).iloc[0]

    return {
        "asof": now.isoformat(),
        "regime": pred["regime"],
        "probability": float(pred["probability"]),
        "transition_timestamp": now.isoformat(),
        "reason": pred.get("reason", "unknown")
    }
