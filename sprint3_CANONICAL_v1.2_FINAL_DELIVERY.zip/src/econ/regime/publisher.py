from typing import Dict

def build_regime_event(regime: str, probability: float, asof: str) -> Dict:
    # Deterministic idempotency key required by REM-3
    return {
        "type": "regime_update",
        "regime": regime,
        "probability": float(probability),
        "asof": asof,
        "idempotency_key": f"regime:{asof}",
    }
